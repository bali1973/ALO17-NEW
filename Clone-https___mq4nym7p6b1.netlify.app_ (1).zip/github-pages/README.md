# ALO17.TR - Türkiye'nin En Büyük Ücretsiz İlan Sitesi

Bu depo, ALO17.TR ilan sitesinin statik HTML versiyonunu içermektedir. Hiçbir değişiklik yapılmadan orijinal site sunulmaktadır.

## Özellikler

- TailwindCSS ile responsive tasarım
- İlan ve özel link oluşturma özellikleri
- Kategori bazlı ilan listeleme
- Öne çıkan ilanlar

## GitHub Pages

Bu site, GitHub Pages üzerinden yayınlanmaktadır.
