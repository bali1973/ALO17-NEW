# GitHub Pages Kullanım Kılavuzu - ALO17.TR

Ana sayfada değişiklik yapmadan GitHub Pages üzerinde sitenizi yayınlamak için bu kılavuzu izleyin.

## Adım 1: GitHub Hesabı Oluşturun (Eğer yoksa)
- [GitHub.com](https://github.com) adresine gidin ve bir hesap oluşturun.

## Adım 2: Yeni Bir Depo (Repository) Oluşturun
1. GitHub'da oturum açın
2. Sağ üst köşede "+" simgesine tıklayın ve "New repository" seçin
3. Depo adını girin (örneğin: `alo17-tr`)
4. Description (Açıklama) kısmını doldurun: "Türkiye'nin En Büyük Ücretsiz İlan Sitesi"
5. "Public" seçeneğini seçin
6. "Add a README file" seçeneğini işaretlemeyin
7. "Create repository" butonuna tıklayın

## Adım 3: Dosyaları GitHub'a Yükleyin
1. Yeni oluşturduğunuz repo sayfasında "uploading an existing file" linkine tıklayın
2. Bu proje dosyalarını sürükleyip bırakın:
   - `index.html`
   - `.nojekyll` (Bu dosya GitHub'ın Jekyll kullanmasını engeller)
   - İsterseniz README.md dosyasını da ekleyebilirsiniz

## Adım 4: GitHub Pages'ı Etkinleştirin
1. Depo sayfanızda "Settings" (Ayarlar) sekmesine tıklayın
2. Sol menüden "Pages" seçeneğini bulun
3. "Source" bölümünde "Branch" kısmında "main" branch'ini seçin
4. "Save" butonuna tıklayın
5. Birkaç dakika bekleyin ve siteniz hazır olacaktır

## Adım 5: Sitenize Erişin
- Ayarlar sonrası GitHub size bir URL gösterecektir: `https://[kullanici-adi].github.io/alo17-tr/`
- Bu URL üzerinden sitenize erişebilirsiniz

## Not
- GitHub Pages üzerinden yayınlanan site tamamen statiktir
- Ana sayfada hiçbir değişiklik yapılmamıştır
- Tüm özellikler orijinal halindedir
